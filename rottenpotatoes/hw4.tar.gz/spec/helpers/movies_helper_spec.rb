require "spec_helper"
include MoviesHelper

# Specs in this file have access to a helper object that includes
# the MoviesHelper. For example:
#
# describe MoviesHelper do
#   describe "string concat" do
#     it "concats two strings with spaces" do
#       expect(helper.concat_strings("this","that")).to eq("this that")
#     end
#   end
# end
describe MoviesHelper do
  describe "delete movie"

		it "1 should be odd" do
			assert_equal oddness(1), "odd"
		end
		
  		it "2 should be even" do
			assert_equal oddness(2), "even"
		end

end
